# Framework Deterministic Navigation

Precompiled Unity package for deterministic layered-grid navigation. Runtime maps are
loaded from the versioned binary format; Unity NavMesh is not authoritative.

Design reference: Trailblazer 1.0.1, commit 76a6ee5, MIT License.
