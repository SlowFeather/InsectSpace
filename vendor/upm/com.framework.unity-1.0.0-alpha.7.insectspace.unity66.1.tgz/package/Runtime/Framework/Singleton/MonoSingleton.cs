using UnityEngine;
namespace Framework.Singleton
{
    //public class TestSingleton : MonoBehaviour
    //{
    //   public  static TestSingleton instance;
    //    private void Awake()
    //    {
    //        instance = this;
    //    }
    //}
    //上面这张写法也是单例，比较简单 但是要求比较特殊，这个脚本组件必须只能在此项目中唯一的物体上有，其他体身上不能有，像主摄像机 
    //【一定要确保这种写法的单例只能出现在场景中唯一的一个物体上】
    public class MonoSingleton<T> : MonoBehaviour where T : MonoBehaviour
    {
        private static string MonoSingletonName = "[MonoSingletonRoot]";
        private static GameObject MonoSingletonRoot;
        private static T instance;

        private static bool _applicationIsQuitting = false;

        public static T Instance
        {
            get
            {
                if (_applicationIsQuitting)
                {
                    return null;
                }
                if (MonoSingletonRoot == null)//如果是第一次调用单例类型就查找所有单例类的总结点
                {
                    MonoSingletonRoot = GameObject.Find(MonoSingletonName);
                    if (MonoSingletonRoot == null)//如果没有找到则创建一个所有继承MonoBehaviour单例类的节点
                    {
                        MonoSingletonRoot = new GameObject();
                        MonoSingletonRoot.name = MonoSingletonName;
                        DontDestroyOnLoad(MonoSingletonRoot);//防止被销毁
                    }
                }
                if (instance == null)//为空表示第一次获取当前单例类
                {
                    instance = MonoSingletonRoot.GetComponent<T>();
                    if (instance == null)//如果当前要调用的单例类不存在则添加一个
                    {
                        instance = MonoSingletonRoot.AddComponent<T>();
                    }
                }
                return instance;
            }
        }

        public static T InitSingleton()
        {
            return Instance;
        }

        public static void CheckInstance()
        {
            if (instance == null)
            {
                Debug.LogError("脚本类<" + typeof(T).Name + "> 无法直接实例化，因为它是一个单例!");
                throw new GameFrameworkException("脚本类<" + typeof(T).Name + "> 无法直接实例化，因为它是一个单例!");
            }
        }

        public void OnDestroy()
        {
            _applicationIsQuitting = true;
            instance = null;
        }

    }
}