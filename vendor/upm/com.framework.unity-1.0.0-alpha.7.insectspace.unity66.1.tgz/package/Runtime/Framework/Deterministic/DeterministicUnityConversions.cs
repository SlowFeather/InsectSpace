using Framework.Deterministic;
using UnityEngine;

namespace UnityFramework.Runtime
{
    /// <summary>Presentation-boundary conversions. Never use Unity values in authoritative simulation state.</summary>
    public static class DeterministicUnityConversions
    {
        public static FPVector2 ToDeterministicXZ(this Vector3 value) => new FPVector2(ToFixed(value.x), ToFixed(value.z));
        public static Vector3 ToUnityXZ(this FPVector2 value, float y = 0f) => new Vector3(ToFloat(value.X), y, ToFloat(value.Y));
        public static FPVector3 ToDeterministic(this Vector3 value) => new FPVector3(ToFixed(value.x), ToFixed(value.y), ToFixed(value.z));
        public static Vector3 ToUnity(this FPVector3 value) => new Vector3(ToFloat(value.X), ToFloat(value.Y), ToFloat(value.Z));
        public static FPQuaternion ToDeterministic(this Quaternion value) => new FPQuaternion(ToFixed(value.x), ToFixed(value.y), ToFixed(value.z), ToFixed(value.w));
        public static Quaternion ToUnity(this FPQuaternion value) => new Quaternion(ToFloat(value.X), ToFloat(value.Y), ToFloat(value.Z), ToFloat(value.W));

        private static FP64 ToFixed(float value) => FP64.FromRaw((long)(value * FP64.OneRaw));
        private static float ToFloat(FP64 value) => (float)value.RawValue / FP64.OneRaw;
    }
}
