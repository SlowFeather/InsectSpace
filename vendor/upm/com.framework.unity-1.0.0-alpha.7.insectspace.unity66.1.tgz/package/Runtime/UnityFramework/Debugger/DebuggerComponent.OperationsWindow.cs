//------------------------------------------------------------
// Game Framework
// Copyright (c) 2013-2021 Jiang Yin. All rights reserved.
// Adapted for Framework.Unity.
//------------------------------------------------------------

using Framework;
using UnityEngine;

namespace UnityFramework.Runtime
{
    public sealed partial class DebuggerComponent : GameComponent
    {
        private sealed class OperationsWindow : ScrollableDebuggerWindowBase
        {
            protected override void OnDrawScrollableWindow()
            {
                GUILayout.Label("<b>Operations</b>");
                GUILayout.BeginVertical("box");

                ObjectPoolComponent objectPoolComponent = UnityFrameworkEntry.GetComponent<ObjectPoolComponent>();
                if (objectPoolComponent != null)
                {
                    if (GUILayout.Button("Object Pool Release", GUILayout.Height(30f)))
                    {
                        objectPoolComponent.Release();
                    }
                    if (GUILayout.Button("Object Pool Release All Unused", GUILayout.Height(30f)))
                    {
                        objectPoolComponent.ReleaseAllUnused();
                    }
                }

                if (GUILayout.Button("Unload Unused Assets", GUILayout.Height(30f)))
                {
                    Resources.UnloadUnusedAssets();
                }
                if (GUILayout.Button("Collect Garbage", GUILayout.Height(30f)))
                {
                    System.GC.Collect();
                }
                if (GUILayout.Button("Shutdown Framework", GUILayout.Height(30f)))
                {
                    UnityFrameworkEntry.Shutdown(ShutdownType.None);
                }
                if (GUILayout.Button("Quit Application", GUILayout.Height(30f)))
                {
                    UnityFrameworkEntry.Shutdown(ShutdownType.Quit);
                }

                GUILayout.EndVertical();
            }
        }
    }
}
