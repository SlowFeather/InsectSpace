namespace UnityFramework.Runtime
{
    /// <summary>
    /// Controls whether the runtime debugger is available in the current build.
    /// </summary>
    public enum DebuggerActiveWindowType : byte
    {
        Editor = 0,
        DevelopmentBuild = 1,
        Always = 2,
        Disabled = 3
    }
}
