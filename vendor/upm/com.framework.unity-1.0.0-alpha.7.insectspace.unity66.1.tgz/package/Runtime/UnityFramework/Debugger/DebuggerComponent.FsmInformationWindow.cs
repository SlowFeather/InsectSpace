using Framework;
using Framework.Fsm;
using UnityEngine;

namespace UnityFramework.Runtime
{
    public sealed partial class DebuggerComponent : GameComponent
    {
        private sealed class FsmInformationWindow : ScrollableDebuggerWindowBase
        {
            private FsmComponent m_FsmComponent;

            public override void Initialize(params object[] args)
            {
                m_FsmComponent = UnityFrameworkEntry.GetComponent<FsmComponent>();
            }

            protected override void OnDrawScrollableWindow()
            {
                GUILayout.Label("<b>FSM Information</b>");
                if (m_FsmComponent == null)
                {
                    GUILayout.Label("FSM component is not available.");
                    return;
                }

                FsmBase[] fsms = m_FsmComponent.GetAllFsms();
                GUILayout.BeginVertical("box");
                DrawItem("FSM Count", fsms.Length.ToString());
                GUILayout.EndVertical();

                for (int i = 0; i < fsms.Length; i++)
                {
                    FsmBase fsm = fsms[i];
                    GUILayout.Label(Utility.Text.Format("<b>{0}</b>", fsm.FullName));
                    GUILayout.BeginVertical("box");
                    DrawItem("Owner Type", fsm.OwnerType.FullName);
                    DrawItem("State Count", fsm.FsmStateCount.ToString());
                    DrawItem("Current State", string.IsNullOrEmpty(fsm.CurrentStateName) ? "None" : fsm.CurrentStateName);
                    DrawItem("Current State Time", Utility.Text.Format("{0:F3} s", fsm.CurrentStateTime));
                    DrawItem("Is Running", fsm.IsRunning.ToString());
                    DrawItem("Is Destroyed", fsm.IsDestroyed.ToString());
                    GUILayout.EndVertical();
                }
            }
        }
    }
}
