//------------------------------------------------------------
// Game Framework
// Copyright (c) 2013-2021 Jiang Yin. All rights reserved.
// Adapted for Framework.Unity.
//------------------------------------------------------------

using UnityEngine;

namespace UnityFramework.Runtime
{
    public sealed partial class DebuggerComponent : GameComponent
    {
        private sealed class SettingsWindow : ScrollableDebuggerWindowBase
        {
            private const string KeyPrefix = "Framework.Debugger.";
            private DebuggerComponent m_DebuggerComponent;
            private Rect m_LastIconRect;
            private Rect m_LastWindowRect;
            private float m_LastWindowScale;

            public override void Initialize(params object[] args)
            {
                m_DebuggerComponent = UnityFrameworkEntry.GetComponent<DebuggerComponent>();
                if (m_DebuggerComponent == null)
                {
                    return;
                }

                m_DebuggerComponent.IconRect = new Rect(
                    PlayerPrefs.GetFloat(KeyPrefix + "Icon.X", DefaultIconRect.x),
                    PlayerPrefs.GetFloat(KeyPrefix + "Icon.Y", DefaultIconRect.y),
                    DefaultIconRect.width,
                    DefaultIconRect.height);
                m_DebuggerComponent.WindowRect = new Rect(
                    PlayerPrefs.GetFloat(KeyPrefix + "Window.X", DefaultWindowRect.x),
                    PlayerPrefs.GetFloat(KeyPrefix + "Window.Y", DefaultWindowRect.y),
                    PlayerPrefs.GetFloat(KeyPrefix + "Window.Width", DefaultWindowRect.width),
                    PlayerPrefs.GetFloat(KeyPrefix + "Window.Height", DefaultWindowRect.height));
                m_DebuggerComponent.WindowScale = PlayerPrefs.GetFloat(KeyPrefix + "Window.Scale", DefaultWindowScale);
                CacheLayout();
            }

            public override void OnUpdate(float elapseSeconds, float realElapseSeconds)
            {
                if (m_DebuggerComponent == null)
                {
                    return;
                }

                if (m_LastIconRect != m_DebuggerComponent.IconRect ||
                    m_LastWindowRect != m_DebuggerComponent.WindowRect ||
                    !Mathf.Approximately(m_LastWindowScale, m_DebuggerComponent.WindowScale))
                {
                    SaveLayout();
                    CacheLayout();
                }
            }

            protected override void OnDrawScrollableWindow()
            {
                GUILayout.Label("<b>Window Settings</b>");
                GUILayout.BeginVertical("box");

                float maxWidth = Mathf.Max(320f, Screen.safeArea.width);
                float maxHeight = Mathf.Max(240f, Screen.safeArea.height);
                float width = DrawSlider("Width", m_DebuggerComponent.WindowRect.width, 320f, maxWidth);
                float height = DrawSlider("Height", m_DebuggerComponent.WindowRect.height, 240f, maxHeight);
                float scale = DrawSlider("Scale", m_DebuggerComponent.WindowScale, 0.5f, 4f);
                m_DebuggerComponent.WindowRect = new Rect(m_DebuggerComponent.WindowRect.x, m_DebuggerComponent.WindowRect.y, width, height);
                m_DebuggerComponent.WindowScale = scale;

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("0.75x", GUILayout.Height(36f))) m_DebuggerComponent.WindowScale = 0.75f;
                if (GUILayout.Button("1.0x", GUILayout.Height(36f))) m_DebuggerComponent.WindowScale = 1f;
                if (GUILayout.Button("1.5x", GUILayout.Height(36f))) m_DebuggerComponent.WindowScale = 1.5f;
                if (GUILayout.Button("2.0x", GUILayout.Height(36f))) m_DebuggerComponent.WindowScale = 2f;
                GUILayout.EndHorizontal();

                if (GUILayout.Button("Reset Layout", GUILayout.Height(36f)))
                {
                    m_DebuggerComponent.ResetLayout();
                    SaveLayout();
                }
                GUILayout.EndVertical();
            }

            private static float DrawSlider(string label, float value, float min, float max)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label(label, GUILayout.Width(60f));
                value = GUILayout.HorizontalSlider(value, min, max);
                GUILayout.Label(value.ToString("F2"), GUILayout.Width(60f));
                GUILayout.EndHorizontal();
                return Mathf.Clamp(value, min, max);
            }

            private void CacheLayout()
            {
                m_LastIconRect = m_DebuggerComponent.IconRect;
                m_LastWindowRect = m_DebuggerComponent.WindowRect;
                m_LastWindowScale = m_DebuggerComponent.WindowScale;
            }

            private void SaveLayout()
            {
                PlayerPrefs.SetFloat(KeyPrefix + "Icon.X", m_DebuggerComponent.IconRect.x);
                PlayerPrefs.SetFloat(KeyPrefix + "Icon.Y", m_DebuggerComponent.IconRect.y);
                PlayerPrefs.SetFloat(KeyPrefix + "Window.X", m_DebuggerComponent.WindowRect.x);
                PlayerPrefs.SetFloat(KeyPrefix + "Window.Y", m_DebuggerComponent.WindowRect.y);
                PlayerPrefs.SetFloat(KeyPrefix + "Window.Width", m_DebuggerComponent.WindowRect.width);
                PlayerPrefs.SetFloat(KeyPrefix + "Window.Height", m_DebuggerComponent.WindowRect.height);
                PlayerPrefs.SetFloat(KeyPrefix + "Window.Scale", m_DebuggerComponent.WindowScale);
                PlayerPrefs.Save();
            }
        }
    }
}
