using System.Collections.Generic;
using Framework.Debugger;
using UnityEngine;

namespace UnityFramework.Runtime
{
    public sealed partial class DebuggerComponent : GameComponent
    {
        private sealed class CommandWindow : IDebuggerWindow
        {
            private const string CommandControlName = "FrameworkDebuggerCommand";
            private readonly List<string> m_History = new List<string>();
            private Vector2 m_ScrollPosition;
            private string m_CommandLine = string.Empty;
            private string m_Status = "Type help to list commands.";
            private int m_HistoryIndex;

            public void Initialize(params object[] args)
            {
                _ = DebuggerCommandRegistry.CommandNames;
            }

            public void Shutdown()
            {
                m_History.Clear();
                m_CommandLine = string.Empty;
                m_Status = string.Empty;
            }

            public void OnEnter()
            {
            }

            public void OnLeave()
            {
            }

            public void OnUpdate(float elapseSeconds, float realElapseSeconds)
            {
            }

            public void OnDraw()
            {
                GUILayout.Label("<b>Command</b>");
                m_ScrollPosition = GUILayout.BeginScrollView(m_ScrollPosition, "box");
                GUILayout.Label(m_Status);
                GUILayout.EndScrollView();

                GUILayout.BeginHorizontal();
                GUI.SetNextControlName(CommandControlName);
                m_CommandLine = GUILayout.TextField(m_CommandLine);
                if (GUILayout.Button("Run", GUILayout.Width(70f)))
                {
                    RunCommand();
                }
                if (GUILayout.Button("Clear", GUILayout.Width(70f)))
                {
                    m_Status = string.Empty;
                    m_History.Clear();
                    m_HistoryIndex = 0;
                }
                GUILayout.EndHorizontal();

                Event current = Event.current;
                if (current.type != EventType.KeyDown || GUI.GetNameOfFocusedControl() != CommandControlName)
                {
                    return;
                }

                switch (current.keyCode)
                {
                    case KeyCode.Return:
                    case KeyCode.KeypadEnter:
                        RunCommand();
                        current.Use();
                        break;
                    case KeyCode.UpArrow:
                        NavigateHistory(-1);
                        current.Use();
                        break;
                    case KeyCode.DownArrow:
                        NavigateHistory(1);
                        current.Use();
                        break;
                    case KeyCode.Tab:
                        m_CommandLine = DebuggerCommandRegistry.Complete(m_CommandLine);
                        current.Use();
                        break;
                }
            }

            private void RunCommand()
            {
                string commandLine = m_CommandLine.Trim();
                if (commandLine.Length == 0)
                {
                    return;
                }

                m_History.Add(commandLine);
                m_HistoryIndex = m_History.Count;
                if (DebuggerCommandRegistry.Execute(commandLine, out string error))
                {
                    m_Status = "> " + commandLine + "\nCommand completed.";
                    Log.Info("Command: {0}", commandLine);
                }
                else
                {
                    m_Status = "> " + commandLine + "\n" + error;
                    Log.Error("Command '{0}' failed: {1}", commandLine, error);
                }
                m_CommandLine = string.Empty;
                GUI.FocusControl(CommandControlName);
            }

            private void NavigateHistory(int direction)
            {
                if (m_History.Count == 0)
                {
                    return;
                }

                m_HistoryIndex = Mathf.Clamp(m_HistoryIndex + direction, 0, m_History.Count);
                m_CommandLine = m_HistoryIndex == m_History.Count ? string.Empty : m_History[m_HistoryIndex];
            }
        }
    }
}
