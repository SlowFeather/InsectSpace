using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace UnityFramework.Runtime
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
    public sealed class DebuggerCommandAttribute : Attribute
    {
        public DebuggerCommandAttribute(string name = null)
        {
            Name = name;
            MaxArgumentCount = -1;
        }

        public string Name { get; }
        public string Help { get; set; }
        public string Usage { get; set; }
        public int MinArgumentCount { get; set; }
        public int MaxArgumentCount { get; set; }
    }

    public readonly struct DebuggerCommandArgument
    {
        public DebuggerCommandArgument(string value)
        {
            Value = value ?? string.Empty;
        }

        public string Value { get; }

        public bool TryGetInt(out int value)
        {
            return int.TryParse(Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
        }

        public bool TryGetFloat(out float value)
        {
            return float.TryParse(Value, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }

        public bool TryGetBool(out bool value)
        {
            return bool.TryParse(Value, out value);
        }

        public override string ToString()
        {
            return Value;
        }
    }

    public static class DebuggerCommandRegistry
    {
        private sealed class CommandInfo
        {
            public Action<DebuggerCommandArgument[]> Handler;
            public string Help;
            public string Usage;
            public int MinArgumentCount;
            public int MaxArgumentCount;
        }

        private static readonly Dictionary<string, CommandInfo> s_Commands = new Dictionary<string, CommandInfo>(StringComparer.OrdinalIgnoreCase);
        private static readonly List<string> s_CommandNames = new List<string>();
        private static bool s_Initialized;

        public static IReadOnlyList<string> CommandNames
        {
            get
            {
                EnsureInitialized();
                return s_CommandNames;
            }
        }

        public static void Register(string name, Action<DebuggerCommandArgument[]> handler, string help = null, string usage = null, int minArgumentCount = 0, int maxArgumentCount = -1)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Command name is invalid.", nameof(name));
            }
            if (handler == null)
            {
                throw new ArgumentNullException(nameof(handler));
            }
            if (minArgumentCount < 0 || (maxArgumentCount >= 0 && maxArgumentCount < minArgumentCount))
            {
                throw new ArgumentOutOfRangeException(nameof(minArgumentCount));
            }

            string normalizedName = name.Trim();
            if (s_Commands.ContainsKey(normalizedName))
            {
                throw new InvalidOperationException("Debugger command '" + normalizedName + "' is already registered.");
            }

            s_Commands.Add(normalizedName, new CommandInfo
            {
                Handler = handler,
                Help = help ?? string.Empty,
                Usage = usage ?? normalizedName,
                MinArgumentCount = minArgumentCount,
                MaxArgumentCount = maxArgumentCount
            });
            s_CommandNames.Add(normalizedName);
            s_CommandNames.Sort(StringComparer.OrdinalIgnoreCase);
        }

        public static bool Execute(string commandLine, out string error)
        {
            EnsureInitialized();
            error = null;

            if (!TryTokenize(commandLine, out List<string> tokens, out error))
            {
                return false;
            }
            if (tokens.Count == 0)
            {
                return true;
            }
            if (!s_Commands.TryGetValue(tokens[0], out CommandInfo command))
            {
                error = "Unknown command '" + tokens[0] + "'. Run 'help' to list commands.";
                return false;
            }

            int argumentCount = tokens.Count - 1;
            if (argumentCount < command.MinArgumentCount || (command.MaxArgumentCount >= 0 && argumentCount > command.MaxArgumentCount))
            {
                error = "Usage: " + command.Usage;
                return false;
            }

            DebuggerCommandArgument[] arguments = new DebuggerCommandArgument[argumentCount];
            for (int i = 0; i < argumentCount; i++)
            {
                arguments[i] = new DebuggerCommandArgument(tokens[i + 1]);
            }

            try
            {
                command.Handler(arguments);
                return true;
            }
            catch (Exception exception)
            {
                error = exception.GetBaseException().Message;
                return false;
            }
        }

        public static string Complete(string input)
        {
            EnsureInitialized();
            string value = input ?? string.Empty;
            int lastSpace = value.LastIndexOf(' ');
            string prefix = lastSpace >= 0 ? value.Substring(0, lastSpace + 1) : string.Empty;
            string partial = lastSpace >= 0 ? value.Substring(lastSpace + 1) : value;
            if (prefix.Length > 0)
            {
                return value;
            }

            string match = null;
            for (int i = 0; i < s_CommandNames.Count; i++)
            {
                string candidate = s_CommandNames[i];
                if (!candidate.StartsWith(partial, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                match = match == null ? candidate : GetCommonPrefix(match, candidate);
            }
            return match ?? value;
        }

        internal static string GetHelpText()
        {
            EnsureInitialized();
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < s_CommandNames.Count; i++)
            {
                string name = s_CommandNames[i];
                CommandInfo command = s_Commands[name];
                builder.Append(name.PadRight(18)).AppendLine(command.Help);
            }
            return builder.ToString();
        }

        private static void EnsureInitialized()
        {
            if (s_Initialized)
            {
                return;
            }

            s_Initialized = true;
            RegisterAttributedCommands();
        }

        private static void RegisterAttributedCommands()
        {
            const BindingFlags flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            for (int assemblyIndex = 0; assemblyIndex < assemblies.Length; assemblyIndex++)
            {
                Type[] types;
                try
                {
                    types = assemblies[assemblyIndex].GetTypes();
                }
                catch (ReflectionTypeLoadException exception)
                {
                    types = exception.Types;
                }
                catch
                {
                    continue;
                }

                for (int typeIndex = 0; typeIndex < types.Length; typeIndex++)
                {
                    Type type = types[typeIndex];
                    if (type == null)
                    {
                        continue;
                    }

                    MethodInfo[] methods;
                    try
                    {
                        methods = type.GetMethods(flags);
                    }
                    catch
                    {
                        continue;
                    }

                    for (int methodIndex = 0; methodIndex < methods.Length; methodIndex++)
                    {
                        MethodInfo method = methods[methodIndex];
                        DebuggerCommandAttribute attribute = method.GetCustomAttribute<DebuggerCommandAttribute>(false);
                        if (attribute == null)
                        {
                            continue;
                        }

                        ParameterInfo[] parameters = method.GetParameters();
                        if (method.ReturnType != typeof(void) || parameters.Length != 1 || parameters[0].ParameterType != typeof(DebuggerCommandArgument[]))
                        {
                            Debug.LogWarning("Ignore debugger command with invalid signature: " + type.FullName + "." + method.Name);
                            continue;
                        }

                        string name = string.IsNullOrWhiteSpace(attribute.Name) ? method.Name : attribute.Name;
                        try
                        {
                            Action<DebuggerCommandArgument[]> handler = (Action<DebuggerCommandArgument[]>)Delegate.CreateDelegate(typeof(Action<DebuggerCommandArgument[]>), method);
                            Register(name, handler, attribute.Help, attribute.Usage, attribute.MinArgumentCount, attribute.MaxArgumentCount);
                        }
                        catch (Exception exception)
                        {
                            Debug.LogWarning("Failed to register debugger command '" + name + "': " + exception.Message);
                        }
                    }
                }
            }
        }

        private static bool TryTokenize(string input, out List<string> tokens, out string error)
        {
            tokens = new List<string>();
            error = null;
            if (string.IsNullOrWhiteSpace(input))
            {
                return true;
            }

            StringBuilder token = new StringBuilder();
            bool quoted = false;
            bool escaped = false;
            for (int i = 0; i < input.Length; i++)
            {
                char character = input[i];
                if (escaped)
                {
                    token.Append(character);
                    escaped = false;
                }
                else if (character == '\\')
                {
                    escaped = true;
                }
                else if (character == '"')
                {
                    quoted = !quoted;
                }
                else if (char.IsWhiteSpace(character) && !quoted)
                {
                    if (token.Length > 0)
                    {
                        tokens.Add(token.ToString());
                        token.Length = 0;
                    }
                }
                else
                {
                    token.Append(character);
                }
            }

            if (escaped)
            {
                token.Append('\\');
            }
            if (quoted)
            {
                error = "Unterminated quoted argument.";
                return false;
            }
            if (token.Length > 0)
            {
                tokens.Add(token.ToString());
            }
            return true;
        }

        private static string GetCommonPrefix(string left, string right)
        {
            int length = Math.Min(left.Length, right.Length);
            int index = 0;
            while (index < length && char.ToUpperInvariant(left[index]) == char.ToUpperInvariant(right[index]))
            {
                index++;
            }
            return left.Substring(0, index);
        }
    }

    internal static class BuiltInDebuggerCommands
    {
        [DebuggerCommand("help", Help = "List registered commands.", MaxArgumentCount = 0)]
        private static void Help(DebuggerCommandArgument[] arguments)
        {
            Log.Info(DebuggerCommandRegistry.GetHelpText());
        }

        [DebuggerCommand("timescale", Help = "Set Unity time scale.", Usage = "timescale <value>", MinArgumentCount = 1, MaxArgumentCount = 1)]
        private static void TimeScale(DebuggerCommandArgument[] arguments)
        {
            if (!arguments[0].TryGetFloat(out float value) || value < 0f)
            {
                throw new ArgumentException("Time scale must be a non-negative number.");
            }
            Time.timeScale = value;
            Log.Info("Time scale: {0}", value);
        }

        [DebuggerCommand("targetfps", Help = "Set application target frame rate.", Usage = "targetfps <value>", MinArgumentCount = 1, MaxArgumentCount = 1)]
        private static void TargetFps(DebuggerCommandArgument[] arguments)
        {
            if (!arguments[0].TryGetInt(out int value))
            {
                throw new ArgumentException("Target FPS must be an integer.");
            }
            Application.targetFrameRate = value;
            Log.Info("Target FPS: {0}", value);
        }

        [DebuggerCommand("gc", Help = "Run managed garbage collection.", MaxArgumentCount = 0)]
        private static void CollectGarbage(DebuggerCommandArgument[] arguments)
        {
            GC.Collect();
            Log.Info("Managed garbage collection completed.");
        }
    }
}
