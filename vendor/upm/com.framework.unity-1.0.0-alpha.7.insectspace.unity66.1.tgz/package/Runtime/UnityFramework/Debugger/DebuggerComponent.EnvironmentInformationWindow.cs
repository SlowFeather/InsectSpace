//------------------------------------------------------------
// Game Framework
// Copyright (c) 2013-2021 Jiang Yin. All rights reserved.
// Adapted for Framework.Unity.
//------------------------------------------------------------

using Framework;
using UnityEngine;

namespace UnityFramework.Runtime
{
    public sealed partial class DebuggerComponent : GameComponent
    {
        private sealed class EnvironmentInformationWindow : ScrollableDebuggerWindowBase
        {
            protected override void OnDrawScrollableWindow()
            {
                GUILayout.Label("<b>Environment Information</b>");
                GUILayout.BeginVertical("box");
                DrawItem("Product Name", Application.productName);
                DrawItem("Company Name", Application.companyName);
                DrawItem("Game Identifier", Application.identifier);
                DrawItem("Framework Version", Framework.Version.FrameworkVersion);
                DrawItem("Game Version", Utility.Text.Format("{0} ({1})", Framework.Version.GameVersion, Framework.Version.InternalGameVersion));
                DrawItem("Application Version", Application.version);
                DrawItem("Unity Version", Application.unityVersion);
                DrawItem("Platform", Application.platform.ToString());
                DrawItem("System Language", Application.systemLanguage.ToString());
                DrawItem("Build Guid", Application.buildGUID);
                DrawItem("Target Frame Rate", Application.targetFrameRate.ToString());
                DrawItem("Internet Reachability", Application.internetReachability.ToString());
                DrawItem("Background Loading Priority", Application.backgroundLoadingPriority.ToString());
                DrawItem("Run In Background", Application.runInBackground.ToString());
                DrawItem("Is Playing", Application.isPlaying.ToString());
                DrawItem("Is Focused", Application.isFocused.ToString());
                DrawItem("Is Batch Mode", Application.isBatchMode.ToString());
                DrawItem("Is Mobile Platform", Application.isMobilePlatform.ToString());
                DrawItem("Is Console Platform", Application.isConsolePlatform.ToString());
                DrawItem("Is Editor", Application.isEditor.ToString());
                DrawItem("Is Debug Build", Debug.isDebugBuild.ToString());
                GUILayout.EndVertical();
            }
        }
    }
}
