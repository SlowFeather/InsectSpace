﻿using Framework;

namespace UnityFramework.Runtime
{
    /// <summary>
    /// System.String 变量类。
    /// </summary>
    public sealed class VarString : Variable<string>
    {
        /// <summary>
        /// 初始化 System.String 变量类的新实例。
        /// </summary>
        public VarString()
        {
        }

        /// <summary>
        /// 从 System.String 到 System.String 变量类的隐式转换。
        /// </summary>
        /// <param name="value">值。</param>
        public static implicit operator VarString(string value)
        {
            VarString varValue = ReferencePool.Acquire<VarString>();
            varValue.Value = value;
            return varValue;
        }

        /// <summary>
        /// 从 System.String 变量类到 System.String 的隐式转换。
        /// </summary>
        /// <param name="value">值。</param>
        public static implicit operator string(VarString value)
        {
            return value.Value;
        }
    }
}
