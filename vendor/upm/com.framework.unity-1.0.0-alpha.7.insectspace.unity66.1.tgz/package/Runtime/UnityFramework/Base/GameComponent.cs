﻿using UnityEngine;

namespace UnityFramework.Runtime
{
    /// <summary>
    /// 游戏框架组件抽象类。
    /// </summary>
    public abstract class GameComponent : MonoBehaviour
    {
        /// <summary>
        /// 游戏框架组件初始化。
        /// </summary>
        protected virtual void Awake()
        {
            UnityFrameworkEntry.RegisterComponent(this);
        }

        /// <summary>
        /// 游戏框架组件销毁。
        /// </summary>
        protected virtual void OnDestroy()
        {
            UnityFrameworkEntry.UnregisterComponent(this);
        }
    }
}
