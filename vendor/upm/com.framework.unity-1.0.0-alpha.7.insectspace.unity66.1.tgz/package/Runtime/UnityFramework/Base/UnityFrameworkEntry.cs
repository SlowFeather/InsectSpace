using Framework;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace UnityFramework.Runtime
{
    /// <summary>
    /// 游戏入口。
    /// </summary>
    public static class UnityFrameworkEntry
    {
        private static readonly GameFrameworkLinkedList<GameComponent> s_GameComponents = new GameFrameworkLinkedList<GameComponent>();

        /// <summary>
        /// 游戏框架所在的场景编号。
        /// 重启时重新加载初始场景，基本用不到，不如让玩家手动重启
        /// </summary>
        internal const int GameSceneId = 0;

        /// <summary>
        /// 获取游戏框架组件。
        /// </summary>
        /// <typeparam name="T">要获取的游戏框架组件类型。</typeparam>
        /// <returns>要获取的游戏框架组件。</returns>
        public static T GetComponent<T>() where T : GameComponent
        {
            return (T)GetComponent(typeof(T));
        }

        /// <summary>
        /// 获取游戏框架组件。
        /// </summary>
        /// <param name="type">要获取的游戏框架组件类型。</param>
        /// <returns>要获取的游戏框架组件。</returns>
        public static GameComponent GetComponent(Type type)
        {
            RemoveInvalidComponents();

            LinkedListNode<GameComponent> current = s_GameComponents.First;
            while (current != null)
            {
                if (current.Value.GetType() == type)
                {
                    return current.Value;
                }

                current = current.Next;
            }

            return null;
        }

        /// <summary>
        /// 获取游戏框架组件。
        /// </summary>
        /// <param name="typeName">要获取的游戏框架组件类型名称。</param>
        /// <returns>要获取的游戏框架组件。</returns>
        public static GameComponent GetComponent(string typeName)
        {
            RemoveInvalidComponents();

            LinkedListNode<GameComponent> current = s_GameComponents.First;
            while (current != null)
            {
                Type type = current.Value.GetType();
                if (type.FullName == typeName || type.Name == typeName)
                {
                    return current.Value;
                }

                current = current.Next;
            }

            return null;
        }

        /// <summary>
        /// 关闭游戏框架。
        /// </summary>
        /// <param name="shutdownType">关闭游戏框架类型。</param>
        public static void Shutdown(ShutdownType shutdownType)
        {
            Debug.LogWarning("Shutdown Game Framework (" + shutdownType + ")...");
            BaseComponent baseComponent = GetComponent<BaseComponent>();
            if (baseComponent != null)
            {
                baseComponent.Shutdown();
                baseComponent = null;
            }

            s_GameComponents.Clear();

            if (shutdownType == ShutdownType.None)
            {
                return;
            }

            if (shutdownType == ShutdownType.Restart)
            {
                //SceneManager.LoadScene(GameFrameworkSceneId);
                return;
            }

            if (shutdownType == ShutdownType.Quit)
            {
                Application.Quit();
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#endif
                return;
            }
        }

        /// <summary>
        /// 注册游戏框架组件。
        /// </summary>
        /// <param name="gameComponent">要注册的游戏框架组件。</param>
        internal static void RegisterComponent(GameComponent gameComponent)
        {
            if (gameComponent == null)
            {
                Debug.LogError("Unity Framework component is invalid.");
                return;
            }

            RemoveInvalidComponents();

            Type type = gameComponent.GetType();

            LinkedListNode<GameComponent> current = s_GameComponents.First;
            while (current != null)
            {
                if (current.Value.GetType() == type)
                {
                    Debug.LogError("Unity Framework component type '" + type.FullName + "' is already exist.");
                    return;
                }

                current = current.Next;
            }

            s_GameComponents.AddLast(gameComponent);
        }

        /// <summary>
        /// 解除注册游戏框架组件。
        /// </summary>
        /// <param name="gameComponent">要解除注册的游戏框架组件。</param>
        internal static void UnregisterComponent(GameComponent gameComponent)
        {
            LinkedListNode<GameComponent> current = s_GameComponents.First;
            while (current != null)
            {
                LinkedListNode<GameComponent> next = current.Next;
                if (current.Value == null || ReferenceEquals(current.Value, gameComponent))
                {
                    s_GameComponents.Remove(current);
                }

                current = next;
            }
        }

        private static void RemoveInvalidComponents()
        {
            LinkedListNode<GameComponent> current = s_GameComponents.First;
            while (current != null)
            {
                LinkedListNode<GameComponent> next = current.Next;
                if (current.Value == null)
                {
                    s_GameComponents.Remove(current);
                }

                current = next;
            }
        }
    }
}
