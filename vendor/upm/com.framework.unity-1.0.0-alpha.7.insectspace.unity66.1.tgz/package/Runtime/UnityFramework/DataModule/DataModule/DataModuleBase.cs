﻿namespace UnityFramework.Runtime
{
    public abstract class DataModuleBase
    {
        public virtual void Release()
        {

        }
    }
}