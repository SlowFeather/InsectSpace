﻿namespace UnityFramework.Runtime
{
    public interface IModuleActivator
    {
        GeneralModule CreateInstance(string moduleName);

    }
}