﻿using System.Reflection;
using UnityEngine;

namespace UnityFramework.Runtime
{
    public class GeneralModule : DataModuleBase
    {
        private string m_name = "";
        public string Name { get { return m_name; } }

        public GeneralModule()
        {
            m_name = this.GetType().Name;
        }


        /// <summary>
        /// 调用它以创建模块
        /// </summary>
        /// <param name="args"></param>
        public virtual void Create(object args = null)
        {
            //Debug.Log("args: " + args);


        }

        /// <summary>
        /// 调用它以释放模块
        /// </summary>
        public override void Release()
        {
            base.Release();
        }


        /// <summary>
        /// 当模块收到消息后，对消息进行一些处理
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        internal void HandleMessage(string msg, object[] args)
        {
            Debug.Log("msg:" + msg + ", args:" + args);

            var mi = this.GetType()
                .GetMethod(msg, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
            if (mi != null)
            {
                mi.Invoke(this, BindingFlags.NonPublic, null, args, null);
            }
            else
            {
                OnModuleMessage(msg, args);
            }

        }


        /// <summary>
        /// 由派生类去实现，用于处理消息
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        protected virtual void OnModuleMessage(string msg, object[] args)
        {
            Debug.Log("msg:" + msg + ", args:" + args);
        }


        protected virtual void Show(object arg)
        {
            Debug.Log("args: " + arg);
        }
    }
}