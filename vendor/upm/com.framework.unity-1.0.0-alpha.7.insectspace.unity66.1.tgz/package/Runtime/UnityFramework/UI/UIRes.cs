using UnityEngine;

namespace UnityFramework.Runtime.UI
{
    /// <summary>
    /// UI 预制体加载入口。
    /// 当前为基于 Resources 的占位实现，接入资源管理方案（如 YooAsset）后替换 LoadPrefab 内部逻辑即可。
    /// </summary>
    public static class UIRes
    {
        /// <summary>
        /// 前缀，初始化时手动设置
        /// </summary>
        public static string UIResRoot = "";

        /// <summary>
        /// 加载UI的Prefab
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static GameObject LoadPrefab(string name)
        {
            return UnityEngine.Resources.Load<GameObject>(UIResRoot + name);
        }
    }
}
