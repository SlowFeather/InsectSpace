﻿using UnityEngine;
using UnityEngine.EventSystems;

namespace UnityFramework.Runtime.UI.UILib.Control
{
	public class UIControl:MonoBehaviour
	{
	    public bool AutoBindUIElement = false;

        protected virtual void Awake()
		{
		    if (AutoBindUIElement)
		    {
		        UIElementBinder.BindAllUIElement(this);
		    }
		}

		public virtual void SetData(object data)
		{ 
		}

		 

		public void SetVisible(bool value)
		{
			this.gameObject.SetActive(value);
		}

		public static void SetVisible(UIBehaviour ui, bool value)
		{
			if (ui != null)
			{
				ui.gameObject.SetActive(value);
			}
		}

		public bool IsVisible { get { return this.gameObject.activeSelf;} }

		public static bool GetVisible(UIBehaviour ui)
		{
			return ui.gameObject.activeSelf;
		}

	}
}
