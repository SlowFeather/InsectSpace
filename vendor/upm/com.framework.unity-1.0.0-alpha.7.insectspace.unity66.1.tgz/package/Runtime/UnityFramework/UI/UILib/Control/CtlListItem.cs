﻿namespace UnityFramework.Runtime.UI.UILib.Control
{
    public class CtlListItem : UIControl
    {
        public CtlListItem()
        {
        }

        public virtual void UpdateItem(int index, object data)
        {

        }
    }
}
