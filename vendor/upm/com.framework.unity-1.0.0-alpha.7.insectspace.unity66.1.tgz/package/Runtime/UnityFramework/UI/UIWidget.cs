﻿namespace UnityFramework.Runtime.UI
{
    public abstract class UIWidget : UIPanel
    {
        public override UITypeDef UIType { get { return UITypeDef.Widget; } }


    }
}