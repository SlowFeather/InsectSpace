﻿namespace UnityFramework.Runtime.UI
{
    /// <summary>
    /// UI类型
    /// </summary>
    public enum UITypeDef
    {
        Unkown = 0,
        /// <summary>
        /// 页面
        /// </summary>
        Page = 1,
        /// <summary>
        /// 窗口
        /// </summary>
        Window = 2,
        /// <summary>
        /// 小部件
        /// </summary>
        Widget = 3,
        /// <summary>
        /// 加载
        /// </summary>
        Loading = 4
    }


    public class UILayerDef
    {
        /// <summary>
        /// 背景
        /// </summary>
        public const int Background = 0;
        /// <summary>
        /// 一般页面
        /// </summary>
        public const int Page = 1000;//-1999
        /// <summary>
        /// 普通弹出窗口
        /// </summary>
        public const int NormalWindow = 2000;//-2999
        /// <summary>
        /// 最顶层的弹出窗口
        /// </summary>
        public const int TopWindow = 3000;//-3999
        /// <summary>
        /// 各种UI小部件
        /// </summary>
        public const int Widget = 4000;//-4999
        /// <summary>
        /// 加载页面
        /// </summary>
        public const int Loading = 5000;
        public const int Unkown = 9999;

        /// <summary>
        /// 获取该层的默认值
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static int GetDefaultLayer(UITypeDef type)
        {
            switch (type)
            {
                case UITypeDef.Loading: return Loading;
                case UITypeDef.Widget: return Widget;
                case UITypeDef.Window: return NormalWindow;
                case UITypeDef.Page: return Page;
                case UITypeDef.Unkown: return Unkown;
                default: return Unkown;
            }
        }

    }


}