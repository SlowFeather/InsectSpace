using Framework;
using Framework.Skill;
using UnityEngine;

namespace UnityFramework.Runtime
{
    /// <summary>
    /// 数据结点组件。
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("Unity Framework/Skill")]
    public sealed class SkillComponent : GameComponent
    {
        private ISkillManager m_SkillManager = null;

        /// <summary>
        /// 游戏框架组件初始化。
        /// </summary>
        protected override void Awake()
        {
            base.Awake();

            m_SkillManager = GameFrameworkEntry.GetModule<ISkillManager>();
            if (m_SkillManager == null)
            {
                Debug.LogError("Skill manager is invalid.");
                return;
            }
        }

        /// <summary>
        /// 添加一个技能到某个人身上
        /// </summary>
        /// <param name="holder"></param>
        /// <param name="skill"></param>
        public void AddSkillToSomeOne(string holder, SkillBase skill)
        {
            m_SkillManager.AddSkillToSomeOne(holder, skill);
        }

        /// <summary>
        /// 从某个人身上移除一个技能
        /// </summary>
        /// <param name="holder"></param>
        /// <param name="skillName"></param>
        /// <exception cref="GameFrameworkException"></exception>
        public void RemoveSkillForSomeOne(string holder, SkillBase skill)
        {
            m_SkillManager.RemoveSkillForSomeOne(holder, skill);
        }

        /// <summary>
        /// 从某个人身上移除一个技能
        /// </summary>
        /// <param name="holder"></param>
        /// <param name="skillName"></param>
        /// <exception cref="GameFrameworkException"></exception>
        public void RemoveSkillForSomeOne(string holder, string skillName)
        {
            m_SkillManager.RemoveSkillForSomeOne(holder, skillName);
        }


        /// <summary>
        /// 移除某个人身上的所有技能
        /// </summary>
        /// <param name="holder"></param>
        /// <exception cref="GameFrameworkException"></exception>
        public void RemoveSomeBodyAllSkill(string holder)
        {
            m_SkillManager.RemoveSomeBodyAllSkill(holder);
        }

        /// <summary>
        /// 发射某个人身上的某个技能
        /// </summary>
        public void FireSomeBodySomeOneSkill(string holder, string skillName)
        {
            m_SkillManager.FireSomeBodySomeOneSkill(holder, skillName);
        }

    }
}
