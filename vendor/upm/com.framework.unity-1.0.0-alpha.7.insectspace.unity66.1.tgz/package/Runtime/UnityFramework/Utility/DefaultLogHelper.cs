using Cysharp.Text;
using Framework;
using System;
using System.Threading;
using UnityEngine;

namespace UnityFramework.Runtime
{
    [Serializable]
    public struct QueuedLog
    {
        public long TimestampTicks;
        public string Message;
        public string StackTrace;
        public LogType LogType;
    }

    /// <summary>
    /// 默认游戏框架日志辅助器。
    /// </summary>
    public sealed class DefaultLogHelper : GameFrameworkLog.ILogHelper, IDisposable
    {
        private const int DefaultLogCacheCount = 1000;
        private const string IgnorePrefix = "CPIGNORE";

        private readonly object m_Lock = new object();
        private QueuedLog[] m_Logs;
        private int m_StartIndex;
        private int m_Count;
        private int m_IgnoreCallbackCount;
        private bool m_Disposed;

        /// <summary>
        /// 获取或设置日志缓存条数。
        /// </summary>
        public int LogCacheCount
        {
            get
            {
                lock (m_Lock)
                {
                    return m_Logs.Length;
                }
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), "Log cache count can not be negative.");
                }

                lock (m_Lock)
                {
                    ResizeCache(value);
                }
            }
        }

        /// <summary>
        /// 获取当前缓存日志数量。
        /// </summary>
        public int CachedLogCount
        {
            get
            {
                lock (m_Lock)
                {
                    return m_Count;
                }
            }
        }

        public DefaultLogHelper()
            : this(DefaultLogCacheCount)
        {
        }

        public DefaultLogHelper(int logCacheCount)
        {
            if (logCacheCount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(logCacheCount), "Log cache count can not be negative.");
            }

            m_Logs = new QueuedLog[logCacheCount];
            Application.logMessageReceivedThreaded += LogCallback;
        }

        public void Dispose()
        {
            if (m_Disposed)
            {
                return;
            }

            Application.logMessageReceivedThreaded -= LogCallback;
            m_Disposed = true;
        }

        private void LogCallback(string logString, string stackTrace, LogType type)
        {
            if (Volatile.Read(ref m_IgnoreCallbackCount) > 0 || logString.StartsWith(IgnorePrefix, StringComparison.Ordinal))
            {
                return;
            }

            QueueLog(logString, stackTrace, type);
        }

        private void QueueLog(string logString, string stackTrace, LogType type)
        {
            lock (m_Lock)
            {
                int capacity = m_Logs.Length;
                if (capacity == 0)
                {
                    return;
                }

                int writeIndex = (m_StartIndex + m_Count) % capacity;
                if (m_Count == capacity)
                {
                    writeIndex = m_StartIndex;
                    m_StartIndex = (m_StartIndex + 1) % capacity;
                }
                else
                {
                    m_Count++;
                }

                m_Logs[writeIndex].TimestampTicks = DateTime.Now.Ticks;
                m_Logs[writeIndex].Message = logString;
                m_Logs[writeIndex].StackTrace = stackTrace;
                m_Logs[writeIndex].LogType = type;
            }
        }

        /// <summary>
        /// 记录日志。
        /// </summary>
        /// <param name="level">日志等级。</param>
        /// <param name="message">日志内容。</param>
        public void Log(GameFrameworkLogLevel level, object message)
        {
            string logMessage = message as string ?? message?.ToString() ?? string.Empty;
            logMessage = LogFormatter.FormatMessage(logMessage);

            switch (level)
            {
                case GameFrameworkLogLevel.Debug:
                case GameFrameworkLogLevel.Info:
                    UnityEngine.Debug.Log(logMessage);
                    break;

                case GameFrameworkLogLevel.Warning:
                    UnityEngine.Debug.LogWarning(logMessage);
                    break;

                case GameFrameworkLogLevel.Error:
                case GameFrameworkLogLevel.Fatal:
                    UnityEngine.Debug.LogError(logMessage);
                    break;

                default:
                    throw new GameFrameworkException("Unknown log level.");
            }
        }

        /// <summary>
        /// 输出所有缓存的日志。
        /// </summary>
        /// <returns>所有缓存的日志。</returns>
        public string PrintAllLogs()
        {
            string result;
            lock (m_Lock)
            {
                using var builder = ZString.CreateStringBuilder();
                for (int i = 0; i < m_Count; i++)
                {
                    QueuedLog log = m_Logs[(m_StartIndex + i) % m_Logs.Length];
                    builder.Append('[');
                    builder.Append(new DateTime(log.TimestampTicks), "HH:mm:ss");
                    builder.Append("] - ");
                    builder.Append(GetLogTypeName(log.LogType));
                    builder.Append(" - ");
                    builder.AppendLine(log.Message);
                    if (!string.IsNullOrEmpty(log.StackTrace))
                    {
                        builder.AppendLine(log.StackTrace);
                    }
                }

                result = builder.ToString();
            }

            Interlocked.Increment(ref m_IgnoreCallbackCount);
            try
            {
                UnityEngine.Debug.Log(result);
            }
            finally
            {
                Interlocked.Decrement(ref m_IgnoreCallbackCount);
            }

            return result;
        }

        private void ResizeCache(int capacity)
        {
            if (capacity == m_Logs.Length)
            {
                return;
            }

            QueuedLog[] resizedLogs = new QueuedLog[capacity];
            int copyCount = Math.Min(m_Count, capacity);
            int skipCount = m_Count - copyCount;
            for (int i = 0; i < copyCount; i++)
            {
                resizedLogs[i] = m_Logs[(m_StartIndex + skipCount + i) % m_Logs.Length];
            }

            m_Logs = resizedLogs;
            m_StartIndex = 0;
            m_Count = copyCount;
        }

        private static string GetLogTypeName(LogType logType)
        {
            switch (logType)
            {
                case LogType.Error:
                    return "Error";
                case LogType.Assert:
                    return "Assert";
                case LogType.Warning:
                    return "Warning";
                case LogType.Log:
                    return "Log";
                case LogType.Exception:
                    return "Exception";
                default:
                    return "Unknown";
            }
        }
    }
}
