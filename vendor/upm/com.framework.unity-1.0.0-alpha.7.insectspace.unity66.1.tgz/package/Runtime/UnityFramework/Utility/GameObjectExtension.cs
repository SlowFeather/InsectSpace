﻿using System;
using UnityEngine;

namespace UnityFramework.Runtime
{
    public static class GameObjectExtension
    {
        /// <summary>
        /// 确保目标 GameObject 拥有指定类型的组件，如果没有则添加并返回该组件
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <returns></returns>
        public static T EnsureComponent<T>(this GameObject target) where T : Component
        {
            T comp = target.GetComponent<T>();
            if (comp == null)
            {
                return target.AddComponent<T>();
            }
            return comp;
        }

        /// <summary>
        /// 确保目标 GameObject 拥有指定类型的组件，如果没有则添加并返回该组件
        /// </summary>
        /// <param name="target"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Component EnsureComponent(this GameObject target, Type type)
        {
            Component comp = target.GetComponent(type);
            if (comp == null)
            {
                return target.AddComponent(type);
            }
            return comp;
        }

        /// <summary>
        /// 在目标 GameObject 及其子物体中查找指定路径下的组件
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static T FindComponent<T>(this GameObject target, string path) where T : Component
        {
            GameObject obj = FindGameObject(target, path);
            if (obj != null)
            {
                return obj.GetComponent<T>();
            }
            return default(T);
        }

        /// <summary>
        /// 在目标 GameObject 及其子物体中查找指定路径下的 GameObject
        /// </summary>
        /// <param name="target"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static GameObject FindGameObject(this GameObject target, string path)
        {
            if (target != null)
            {
                Transform t = target.transform.Find(path);
                if (t != null)
                {
                    return t.gameObject;
                }
            }

            return null;

        }

        /// <summary>
        /// 使用更复杂的方式在目标 GameObject 及其子物体中查找指定路径下的 GameObject
        /// </summary>
        /// <param name="target"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        private static GameObject FindGameObject2(GameObject target, string path)
        {
            if (target == null)
            {
                return null;
            }

            string[] array = path.Split('.');
            Transform current = target.transform;

            for (int i = 0; i < array.Length; ++i)
            {
                string name = array[i];
                Transform child = current.Find(name);
                if (child != null)
                {
                    current = child;
                }
                else
                {
                    char[] c = name.ToCharArray();
                    if (Char.IsLower(c[0]))
                    {
                        c[0] = Char.ToUpper(c[0]);
                    }
                    else
                    {
                        c[0] = Char.ToLower(c[0]);
                    }

                    name = new string(c);
                    child = current.Find(name);
                    if (child != null)
                    {
                        current = child;
                    }
                    else
                    {
                        current = null;
                        break;
                    }
                }
            }

            if (current == null)
            {
                return null;
            }

            return current.gameObject;

        }

        /// <summary>
        /// 在目标 GameObject 及其子物体中通过名称查找 GameObject
        /// </summary>
        /// <param name="root"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static GameObject FindGameObjbyName(this GameObject root, string name)
        {
            if (root == null)
            {
                return GameObject.Find(name);
            }

            Transform[] childs = root.GetComponentsInChildren<Transform>();

            foreach (Transform trans in childs)
            {
                if (trans.gameObject.name.Equals(name))
                {
                    return trans.gameObject;
                }
            }

            return null;
        }

        /// <summary>
        /// 在目标 GameObject 及其子物体中通过前缀查找第一个匹配的 GameObject
        /// </summary>
        /// <param name="root"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public static GameObject FindFirstGameObjByPrefix(this GameObject root, string prefix)
        {
            Transform[] childs;
            if (root != null)
            {
                childs = root.GetComponentsInChildren<Transform>();
            }
            else
            {
                childs = GameObject.FindObjectsOfType<Transform>();
            }

            foreach (Transform trans in childs)
            {
                if (trans.gameObject.name.Length >= prefix.Length)
                {
                    if (trans.gameObject.name.Substring(0, prefix.Length) == prefix)
                    {
                        return trans.gameObject;
                    }
                }

            }

            return null;
        }

        /// <summary>
        /// 递归设置目标 GameObject 及其子物体的激活状态
        /// </summary>
        /// <param name="target"></param>
        /// <param name="bActive"></param>
        public static void SetActiveRecursively(this GameObject target, bool bActive)
        {
#if (!UNITY_3_5)
            for (int n = target.transform.childCount - 1; 0 <= n; n--)
                if (n < target.transform.childCount)
                    SetActiveRecursively(target.transform.GetChild(n).gameObject, bActive);
            target.SetActive(bActive);
#else
		target.SetActiveRecursively(bActive);
#endif
        }

        /// <summary>
        /// 递归设置目标 GameObject 及其子物体的层级
        /// </summary>
        /// <param name="target"></param>
        /// <param name="layer"></param>
        public static void SetLayerRecursively(this GameObject target, int layer)
        {
#if (!UNITY_3_5)
            for (int n = target.transform.childCount - 1; 0 <= n; n--)
            {
                if (n < target.transform.childCount)
                {
                    SetLayerRecursively(target.transform.GetChild(n).gameObject, layer);
                }
            }
            target.layer = layer;
#else
		target.SetActiveRecursively(bActive);
#endif
        }


    }

}
