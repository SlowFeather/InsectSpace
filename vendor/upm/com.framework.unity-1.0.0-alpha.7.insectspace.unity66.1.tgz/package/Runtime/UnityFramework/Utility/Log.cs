using Framework;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace UnityFramework.Runtime
{
    /// <summary>
    /// 游戏日志工具集。
    /// </summary>
    public static class Log
    {
        public readonly struct LogCallerInfo
        {
        }

        public static string PrintAllLog()
        {
            return GameFrameworkLog.PrintAllLogs();
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_DEBUG_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        public static void Debug(object message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Debug, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_DEBUG_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        public static void Debug(string message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Debug, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_DEBUG_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        public static void Debug<T1>(string format, T1 arg1, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Debug, format, arg1, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_DEBUG_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        public static void Debug<T1, T2>(string format, T1 arg1, T2 arg2, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Debug, format, arg1, arg2, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_DEBUG_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        public static void Debug<T1, T2, T3>(string format, T1 arg1, T2 arg2, T3 arg3, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Debug, format, arg1, arg2, arg3, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_DEBUG_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        public static void Debug<T1, T2, T3, T4>(string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Debug, format, arg1, arg2, arg3, arg4, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_INFO_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        public static void Info(object message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Info, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_INFO_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        public static void Info(string message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Info, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_INFO_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        public static void Info<T1>(string format, T1 arg1, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Info, format, arg1, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_INFO_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        public static void Info<T1, T2>(string format, T1 arg1, T2 arg2, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Info, format, arg1, arg2, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_INFO_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        public static void Info<T1, T2, T3>(string format, T1 arg1, T2 arg2, T3 arg3, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Info, format, arg1, arg2, arg3, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_INFO_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        public static void Info<T1, T2, T3, T4>(string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Info, format, arg1, arg2, arg3, arg4, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_WARNING_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        public static void Warning(object message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Warning, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_WARNING_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        public static void Warning(string message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Warning, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_WARNING_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        public static void Warning<T1>(string format, T1 arg1, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Warning, format, arg1, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_WARNING_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        public static void Warning<T1, T2>(string format, T1 arg1, T2 arg2, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Warning, format, arg1, arg2, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_WARNING_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        public static void Warning<T1, T2, T3>(string format, T1 arg1, T2 arg2, T3 arg3, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Warning, format, arg1, arg2, arg3, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_WARNING_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        public static void Warning<T1, T2, T3, T4>(string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Warning, format, arg1, arg2, arg3, arg4, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_ERROR_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        public static void Error(object message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Error, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_ERROR_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        public static void Error(string message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Error, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_ERROR_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        public static void Error<T1>(string format, T1 arg1, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Error, format, arg1, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_ERROR_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        public static void Error<T1, T2>(string format, T1 arg1, T2 arg2, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Error, format, arg1, arg2, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_ERROR_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        public static void Error<T1, T2, T3>(string format, T1 arg1, T2 arg2, T3 arg3, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Error, format, arg1, arg2, arg3, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_ERROR_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        public static void Error<T1, T2, T3, T4>(string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Error, format, arg1, arg2, arg3, arg4, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_FATAL_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        [Conditional("ENABLE_FATAL_AND_ABOVE_LOG")]
        public static void Fatal(object message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Fatal, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_FATAL_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        [Conditional("ENABLE_FATAL_AND_ABOVE_LOG")]
        public static void Fatal(string message, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Fatal, message, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_FATAL_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        [Conditional("ENABLE_FATAL_AND_ABOVE_LOG")]
        public static void Fatal<T1>(string format, T1 arg1, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Fatal, format, arg1, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_FATAL_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        [Conditional("ENABLE_FATAL_AND_ABOVE_LOG")]
        public static void Fatal<T1, T2>(string format, T1 arg1, T2 arg2, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Fatal, format, arg1, arg2, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_FATAL_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        [Conditional("ENABLE_FATAL_AND_ABOVE_LOG")]
        public static void Fatal<T1, T2, T3>(string format, T1 arg1, T2 arg2, T3 arg3, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Fatal, format, arg1, arg2, arg3, filePath, memberName);
        }

        [Conditional("ENABLE_LOG")]
        [Conditional("ENABLE_FATAL_LOG")]
        [Conditional("ENABLE_DEBUG_AND_ABOVE_LOG")]
        [Conditional("ENABLE_INFO_AND_ABOVE_LOG")]
        [Conditional("ENABLE_WARNING_AND_ABOVE_LOG")]
        [Conditional("ENABLE_ERROR_AND_ABOVE_LOG")]
        [Conditional("ENABLE_FATAL_AND_ABOVE_LOG")]
        public static void Fatal<T1, T2, T3, T4>(string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, LogCallerInfo callerInfo = default, [CallerFilePath] string filePath = "", [CallerMemberName] string memberName = "")
        {
            Write(GameFrameworkLogLevel.Fatal, format, arg1, arg2, arg3, arg4, filePath, memberName);
        }

        private static void Write(GameFrameworkLogLevel level, object message, string filePath, string memberName)
        {
            using var scope = GameFrameworkLog.PushLogContext(filePath, memberName);
            switch (level)
            {
                case GameFrameworkLogLevel.Debug: GameFrameworkLog.Debug(message); break;
                case GameFrameworkLogLevel.Info: GameFrameworkLog.Info(message); break;
                case GameFrameworkLogLevel.Warning: GameFrameworkLog.Warning(message); break;
                case GameFrameworkLogLevel.Error: GameFrameworkLog.Error(message); break;
                case GameFrameworkLogLevel.Fatal: GameFrameworkLog.Fatal(message); break;
                default: throw new GameFrameworkException("Unknown log level.");
            }
        }

        private static void Write<T1>(GameFrameworkLogLevel level, string format, T1 arg1, string filePath, string memberName)
        {
            using var scope = GameFrameworkLog.PushLogContext(filePath, memberName);
            switch (level)
            {
                case GameFrameworkLogLevel.Debug: GameFrameworkLog.Debug(format, arg1); break;
                case GameFrameworkLogLevel.Info: GameFrameworkLog.Info(format, arg1); break;
                case GameFrameworkLogLevel.Warning: GameFrameworkLog.Warning(format, arg1); break;
                case GameFrameworkLogLevel.Error: GameFrameworkLog.Error(format, arg1); break;
                case GameFrameworkLogLevel.Fatal: GameFrameworkLog.Fatal(format, arg1); break;
                default: throw new GameFrameworkException("Unknown log level.");
            }
        }

        private static void Write<T1, T2>(GameFrameworkLogLevel level, string format, T1 arg1, T2 arg2, string filePath, string memberName)
        {
            using var scope = GameFrameworkLog.PushLogContext(filePath, memberName);
            switch (level)
            {
                case GameFrameworkLogLevel.Debug: GameFrameworkLog.Debug(format, arg1, arg2); break;
                case GameFrameworkLogLevel.Info: GameFrameworkLog.Info(format, arg1, arg2); break;
                case GameFrameworkLogLevel.Warning: GameFrameworkLog.Warning(format, arg1, arg2); break;
                case GameFrameworkLogLevel.Error: GameFrameworkLog.Error(format, arg1, arg2); break;
                case GameFrameworkLogLevel.Fatal: GameFrameworkLog.Fatal(format, arg1, arg2); break;
                default: throw new GameFrameworkException("Unknown log level.");
            }
        }

        private static void Write<T1, T2, T3>(GameFrameworkLogLevel level, string format, T1 arg1, T2 arg2, T3 arg3, string filePath, string memberName)
        {
            using var scope = GameFrameworkLog.PushLogContext(filePath, memberName);
            switch (level)
            {
                case GameFrameworkLogLevel.Debug: GameFrameworkLog.Debug(format, arg1, arg2, arg3); break;
                case GameFrameworkLogLevel.Info: GameFrameworkLog.Info(format, arg1, arg2, arg3); break;
                case GameFrameworkLogLevel.Warning: GameFrameworkLog.Warning(format, arg1, arg2, arg3); break;
                case GameFrameworkLogLevel.Error: GameFrameworkLog.Error(format, arg1, arg2, arg3); break;
                case GameFrameworkLogLevel.Fatal: GameFrameworkLog.Fatal(format, arg1, arg2, arg3); break;
                default: throw new GameFrameworkException("Unknown log level.");
            }
        }

        private static void Write<T1, T2, T3, T4>(GameFrameworkLogLevel level, string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, string filePath, string memberName)
        {
            using var scope = GameFrameworkLog.PushLogContext(filePath, memberName);
            switch (level)
            {
                case GameFrameworkLogLevel.Debug: GameFrameworkLog.Debug(format, arg1, arg2, arg3, arg4); break;
                case GameFrameworkLogLevel.Info: GameFrameworkLog.Info(format, arg1, arg2, arg3, arg4); break;
                case GameFrameworkLogLevel.Warning: GameFrameworkLog.Warning(format, arg1, arg2, arg3, arg4); break;
                case GameFrameworkLogLevel.Error: GameFrameworkLog.Error(format, arg1, arg2, arg3, arg4); break;
                case GameFrameworkLogLevel.Fatal: GameFrameworkLog.Fatal(format, arg1, arg2, arg3, arg4); break;
                default: throw new GameFrameworkException("Unknown log level.");
            }
        }
    }
}
