using Cysharp.Text;
using Framework;
using System;

namespace UnityFramework.Runtime
{
    internal static class LogFormatter
    {
        private const string TimestampFormat = "yyyy-MM-dd HH:mm:ss.fff";

        public static Utf16ValueStringBuilder AppendContextPrefix(Utf16ValueStringBuilder builder)
        {
            if (!GameFrameworkLog.TryGetLogContext(out string filePath, out string memberName))
            {
                return builder;
            }

            builder = AppendPrefix(builder, filePath, memberName);
            GameFrameworkLog.MarkLogContextFormatted();
            return builder;
        }

        public static string FormatMessage(string message)
        {
            if (GameFrameworkLog.IsLogContextFormatted)
            {
                return message;
            }

            GameFrameworkLog.TryGetLogContext(out string filePath, out string memberName);
            using var builder = AppendPrefix(ZString.CreateStringBuilder(), filePath, memberName);
            builder.Append(message);
            return builder.ToString();
        }

        private static Utf16ValueStringBuilder AppendPrefix(Utf16ValueStringBuilder builder, string filePath, string memberName)
        {
            builder.Append('[');
            builder.Append(DateTime.Now, TimestampFormat);
            builder.Append("] ");

            if (string.IsNullOrEmpty(filePath) && string.IsNullOrEmpty(memberName))
            {
                return builder;
            }

            builder.Append('[');
            builder = AppendScriptName(builder, filePath);
            if (!string.IsNullOrEmpty(filePath) && !string.IsNullOrEmpty(memberName))
            {
                builder.Append('.');
            }

            builder.Append(memberName);
            builder.Append("] ");
            return builder;
        }

        private static Utf16ValueStringBuilder AppendScriptName(Utf16ValueStringBuilder builder, string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                return builder;
            }

            int startIndex = 0;
            int endIndex = filePath.Length;
            for (int i = filePath.Length - 1; i >= 0; i--)
            {
                char character = filePath[i];
                if (character == '.' && endIndex == filePath.Length)
                {
                    endIndex = i;
                }
                else if (character == '/' || character == '\\')
                {
                    startIndex = i + 1;
                    break;
                }
            }

            builder.Append(filePath.AsSpan(startIndex, endIndex - startIndex));
            return builder;
        }
    }
}
