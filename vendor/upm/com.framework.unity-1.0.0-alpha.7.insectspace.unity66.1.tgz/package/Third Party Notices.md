# Third Party Notices

Parts of the runtime debugger are adapted from UnityGameFramework by Jiang Yin:

- https://github.com/EllanJiang/UnityGameFramework
- Copyright (c) 2013-2021 Jiang Yin
- Licensed under the MIT License.

The command registration design is adapted from GFExtension-DebuggerPlus by Shaun Fong,
which in turn credits stillwwater/command_terminal:

- https://github.com/Shaun-Fong/GFExtension-DebuggerPlus
- https://github.com/stillwwater/command_terminal
- Licensed under the MIT License.

The full MIT license text is available in the repository root `LICENSE` file.
