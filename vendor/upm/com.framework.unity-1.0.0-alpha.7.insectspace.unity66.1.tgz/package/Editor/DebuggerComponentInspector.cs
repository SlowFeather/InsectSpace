//------------------------------------------------------------
// Game Framework
// Copyright (c) 2013-2021 Jiang Yin. All rights reserved.
// Adapted for Framework.Unity.
//------------------------------------------------------------

using UnityEditor;
using UnityEngine;
using UnityFramework.Runtime;

namespace UnityFramework.Editor
{
    [CustomEditor(typeof(DebuggerComponent))]
    internal sealed class DebuggerComponentInspector : UnityEditor.Editor
    {
        private SerializedProperty m_Skin;
        private SerializedProperty m_ActiveWindow;
        private SerializedProperty m_ShowFullWindow;
        private SerializedProperty m_MaxLogCount;
        private SerializedProperty m_ConsoleWindow;

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.PropertyField(m_Skin);
            if (EditorApplication.isPlaying)
            {
                DebuggerComponent component = (DebuggerComponent)target;
                component.ActiveWindow = EditorGUILayout.Toggle("Active Window", component.ActiveWindow);
            }
            else
            {
                EditorGUILayout.PropertyField(m_ActiveWindow, new GUIContent("Enable Policy"));
            }

            EditorGUILayout.PropertyField(m_ShowFullWindow);
            EditorGUILayout.PropertyField(m_MaxLogCount, new GUIContent("Log Capacity"));
            EditorGUILayout.PropertyField(m_ConsoleWindow, true);

            if (EditorApplication.isPlaying && GUILayout.Button("Reset Layout"))
            {
                ((DebuggerComponent)target).ResetLayout();
            }

            serializedObject.ApplyModifiedProperties();
        }

        private void OnEnable()
        {
            m_Skin = serializedObject.FindProperty("m_Skin");
            m_ActiveWindow = serializedObject.FindProperty("m_ActiveWindow");
            m_ShowFullWindow = serializedObject.FindProperty("m_ShowFullWindow");
            m_MaxLogCount = serializedObject.FindProperty("m_MaxLogCount");
            m_ConsoleWindow = serializedObject.FindProperty("m_ConsoleWindow");
        }
    }
}
