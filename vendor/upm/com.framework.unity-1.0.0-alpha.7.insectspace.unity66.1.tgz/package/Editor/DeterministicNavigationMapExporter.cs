using System;
using System.Collections.Generic;
using System.IO;
using Framework.Deterministic;
using Framework.Deterministic.Navigation;
using UnityEditor;
using UnityEngine;

namespace UnityFramework.Editor
{
    /// <summary>Editor-only Terrain/Collider baker for the deterministic runtime map format.</summary>
    public static class DeterministicNavigationMapExporter
    {
        public sealed class GridSettings
        {
            public Bounds WorldBounds { get; set; }
            public float CellSize { get; set; } = 1f;
            public LayerMask SurfaceLayers { get; set; } = ~0;
            public LayerMask BlockingLayers { get; set; }
            public short SurfaceLayer { get; set; }
            public uint TraversalMask { get; set; } = uint.MaxValue;
            public ushort TerrainCost { get; set; } = 1;
            public float ProbeHeight { get; set; } = 128f;
            public float BlockerHeight { get; set; } = 2f;
        }

        public static NavigationMap Bake(GridSettings settings)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (settings.CellSize <= 0f) throw new ArgumentOutOfRangeException(nameof(settings.CellSize));
            if (settings.TerrainCost == 0) throw new ArgumentOutOfRangeException(nameof(settings.TerrainCost));

            int width = Mathf.CeilToInt(settings.WorldBounds.size.x / settings.CellSize);
            int depth = Mathf.CeilToInt(settings.WorldBounds.size.z / settings.CellSize);
            if (width <= 0 || depth <= 0) throw new ArgumentException("World bounds must contain at least one grid cell.");
            var heights = new long[width * depth];
            var passable = new bool[width * depth];

            for (int z = 0; z < depth; z++)
            for (int x = 0; x < width; x++)
            {
                int index = z * width + x;
                float worldX = settings.WorldBounds.min.x + (x + 0.5f) * settings.CellSize;
                float worldZ = settings.WorldBounds.min.z + (z + 0.5f) * settings.CellSize;
                Vector3 origin = new Vector3(worldX, settings.WorldBounds.max.y + settings.ProbeHeight, worldZ);
                if (!Physics.Raycast(origin, Vector3.down, out RaycastHit hit, settings.WorldBounds.size.y + settings.ProbeHeight * 2f, settings.SurfaceLayers, QueryTriggerInteraction.Ignore))
                    continue;

                heights[index] = ToRaw(hit.point.y);
                Vector3 halfExtents = new Vector3(settings.CellSize * 0.45f, settings.BlockerHeight * 0.5f, settings.CellSize * 0.45f);
                Vector3 blockerCenter = hit.point + Vector3.up * halfExtents.y;
                passable[index] = !Physics.CheckBox(blockerCenter, halfExtents, Quaternion.identity, settings.BlockingLayers, QueryTriggerInteraction.Ignore);
            }

            byte[] clearance = BuildClearance(width, depth, passable);
            var builder = new NavigationMapBuilder();
            for (int z = 0; z < depth; z++)
            for (int x = 0; x < width; x++)
            {
                int index = z * width + x;
                builder.AddCell(new NavigationCell(index, new NavigationCellCoordinate(x, z, settings.SurfaceLayer), heights[index], settings.TerrainCost, passable[index] ? settings.TraversalMask : 0u, clearance[index]));
            }
            return builder.Build();
        }

        public static ulong BakeToFile(GridSettings settings, string outputPath)
        {
            if (string.IsNullOrWhiteSpace(outputPath)) throw new ArgumentException("Output path is required.", nameof(outputPath));
            NavigationMap map = Bake(settings);
            string directory = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            using (var stream = File.Create(outputPath)) NavigationMapSerializer.Write(stream, map);
            AssetDatabase.Refresh();
            return map.ContentHash;
        }

        private static byte[] BuildClearance(int width, int depth, bool[] passable)
        {
            var result = new byte[passable.Length];
            for (int z = depth - 1; z >= 0; z--)
            for (int x = width - 1; x >= 0; x--)
            {
                int index = z * width + x;
                if (!passable[index]) { result[index] = 1; continue; }
                int right = x + 1 < width ? result[index + 1] : 0;
                int down = z + 1 < depth ? result[index + width] : 0;
                int diagonal = x + 1 < width && z + 1 < depth ? result[index + width + 1] : 0;
                result[index] = (byte)Mathf.Clamp(1 + Mathf.Min(right, Mathf.Min(down, diagonal)), 1, 8);
            }
            return result;
        }

        private static long ToRaw(float value)
        {
            decimal scaled = (decimal)value * FP64.OneRaw;
            if (scaled > long.MaxValue || scaled < long.MinValue) throw new OverflowException("Navigation height is outside Q32.32 range.");
            return decimal.ToInt64(decimal.Round(scaled, 0, MidpointRounding.AwayFromZero));
        }
    }
}
