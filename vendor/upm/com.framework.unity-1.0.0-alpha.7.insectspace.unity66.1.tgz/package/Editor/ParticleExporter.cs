using UnityEngine;
using UnityEditor;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

public class ParticleExporter : MonoBehaviour
{
    // === �������� ===
    public string folder = "PNG_Animations";  // ����������ļ���
    public int frameRate = 25;                // ������֡��
    public float frameCount = 100;            // Ҫ������֡��

    // === ������� ===
    public Vector3 cameraPosition = Vector3.zero;  // ���λ��
    public Vector3 cameraRotation = Vector3.zero;  // �����ת

    // === ˽�б��� ===
    private string realFolder;                      // ʵ�ʵ�����ļ���
    private float originalTimeScale;                // ԭʼ��ʱ�����ţ�������֮ͣ֡��Ķ���
    private float currentTime = 0;
    private bool isExportOver = false;
    private int currentFrameIndex = 0;
    private Camera exportCamera;

    public void Start()
    {
        Initialize();
    }
    private void Initialize()
    {
        // ��ʼ��ʱ���֡��
        Time.captureFramerate = frameRate;
        originalTimeScale = Time.timeScale;

        // ��������ļ���
        realFolder = Path.Combine(folder, name);
        if (!Directory.Exists(realFolder))
        {
            Directory.CreateDirectory(realFolder);
        }

        // �������
        ConfigureCamera();
    }

    private void ConfigureCamera()
    {
        GameObject mainCameraGO = Camera.main.gameObject;
        if (cameraPosition != Vector3.zero)
        {
            mainCameraGO.transform.position = cameraPosition;
        }

        if (cameraRotation != Vector3.zero)
        {
            mainCameraGO.transform.rotation = Quaternion.Euler(cameraRotation);
        }

        GameObject cameraClone = Instantiate(mainCameraGO);
        exportCamera = cameraClone.GetComponent<Camera>();
    }
    private void HandleFrameExport()
    {
        currentTime += Time.deltaTime;
        if (!isExportOver && currentFrameIndex >= frameCount)
        {
            isExportOver = true;
            Cleanup();
            Debug.Log("������ɡ�");
            return;
        }

        StartCoroutine(CaptureFrame());
    }

    private void Cleanup()
    {
        DestroyImmediate(exportCamera.gameObject);
        DestroyImmediate(gameObject);
    }

    void Update()
    {
        HandleFrameExport();
    }

    IEnumerator CaptureFrame()
    {
        // Stop time
        Time.timeScale = 0;
        // Yield to next frame and then start the rendering
        // this is important, otherwise will have error
        yield return new WaitForEndOfFrame();

        string filename = String.Format("{0}/{1:D04}.png", realFolder, ++currentFrameIndex);
        Debug.Log(filename);

        int width = Screen.width;
        int height = Screen.height;

        //Initialize and render textures
        RenderTexture blackCamRenderTexture = new RenderTexture(width, height, 32, RenderTextureFormat.ARGB32);
        RenderTexture whiteCamRenderTexture = new RenderTexture(width, height, 32, RenderTextureFormat.ARGB32);

        exportCamera.targetTexture = blackCamRenderTexture;
        exportCamera.backgroundColor = Color.black;
        exportCamera.Render();
        RenderTexture.active = blackCamRenderTexture;
        Texture2D texb = GetTex2D();

        //Now do it for Alpha Camera
        exportCamera.targetTexture = whiteCamRenderTexture;
        exportCamera.backgroundColor = Color.white;
        exportCamera.Render();
        RenderTexture.active = whiteCamRenderTexture;
        Texture2D texw = GetTex2D();

        // If we have both textures then create final output texture
        if (texw && texb)
        {
            Texture2D outputtex = new Texture2D(width, height, TextureFormat.ARGB32, false);

            // we need to check alpha ourselves,because particle use additive shader
            // Create Alpha from the difference between black and white camera renders
            for (int y = 0; y < outputtex.height; ++y)
            { // each row
                for (int x = 0; x < outputtex.width; ++x)
                { // each column
                    float alpha;
                    alpha = texw.GetPixel(x, y).r - texb.GetPixel(x, y).r;
                    alpha = 1.0f - alpha;
                    Color color;
                    if (alpha == 0)
                    {
                        color = Color.clear;
                    }
                    else
                    {
                        color = texb.GetPixel(x, y);
                    }
                    color.a = alpha;
                    outputtex.SetPixel(x, y, color);
                }
            }


            // Encode the resulting output texture to a byte array then write to the file
            byte[] pngShot = outputtex.EncodeToPNG();
            File.WriteAllBytes(filename, pngShot);

            // cleanup, otherwise will memory leak
            pngShot = null;
            RenderTexture.active = null;
            DestroyImmediate(outputtex);
            outputtex = null;
            DestroyImmediate(blackCamRenderTexture);
            blackCamRenderTexture = null;
            DestroyImmediate(whiteCamRenderTexture);
            whiteCamRenderTexture = null;
            DestroyImmediate(texb);
            texb = null;
            DestroyImmediate(texw);
            texb = null;

            System.GC.Collect();

            // Reset the time scale, then move on to the next frame.
            Time.timeScale = originalTimeScale;
        }
    }

    // Get the texture from the screen, render all or only half of the camera
    private Texture2D GetTex2D()
    {
        // Create a texture the size of the screen, RGB24 format
        int width = Screen.width;
        int height = Screen.height;
        Texture2D tex = new Texture2D(width, height, TextureFormat.ARGB32, false);
        // Read screen contents into the texture
        tex.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        tex.Apply();
        return tex;
    }
}