using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Callbacks;
using UnityEngine;

namespace UnityFramework.Editor
{
    /// <summary>
    /// Redirects Console double-clicks from framework log wrappers to the first user stack frame.
    /// </summary>
    [InitializeOnLoad]
    internal static class EditorLogRedirect
    {
        private static readonly Regex s_StackFrameRegex = new Regex(@"\(at\s+(.+):(\d+)\)", RegexOptions.Compiled);
        private static readonly HashSet<int> s_WrapperScriptIds = new HashSet<int>();
        private static readonly FieldInfo s_ActiveTextField;
        private static readonly FieldInfo s_ConsoleWindowField;

        static EditorLogRedirect()
        {
            Type consoleWindowType = typeof(EditorWindow).Assembly.GetType("UnityEditor.ConsoleWindow");
            if (consoleWindowType != null)
            {
                s_ActiveTextField = consoleWindowType.GetField("m_ActiveText", BindingFlags.Instance | BindingFlags.NonPublic);
                s_ConsoleWindowField = consoleWindowType.GetField("ms_ConsoleWindow", BindingFlags.Static | BindingFlags.NonPublic);
            }

            CacheWrapperScripts("DefaultLogHelper");
            CacheWrapperScripts("Log");
            CacheWrapperScripts("LogFormatter");
        }

        [OnOpenAsset(-100)]
        private static bool OnOpenAsset(int instanceId, int line)
        {
            if (!s_WrapperScriptIds.Contains(instanceId))
            {
                return false;
            }

            string consoleText = GetActiveConsoleText();
            if (string.IsNullOrEmpty(consoleText))
            {
                return false;
            }

            MatchCollection matches = s_StackFrameRegex.Matches(consoleText);
            for (int i = 0; i < matches.Count; i++)
            {
                string path = NormalizeAssetPath(matches[i].Groups[1].Value);
                if (IsFrameworkLogWrapper(path))
                {
                    continue;
                }

                UnityEngine.Object asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(path);
                if (asset == null || !int.TryParse(matches[i].Groups[2].Value, out int targetLine))
                {
                    continue;
                }

                EditorGUIUtility.PingObject(asset);
                return AssetDatabase.OpenAsset(asset, targetLine);
            }

            return false;
        }

        private static void CacheWrapperScripts(string fileName)
        {
            string[] guids = AssetDatabase.FindAssets(fileName + " t:MonoScript");
            for (int i = 0; i < guids.Length; i++)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                if (!IsFrameworkLogWrapper(path))
                {
                    continue;
                }

                MonoScript script = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
                if (script != null)
                {
                    s_WrapperScriptIds.Add(script.GetInstanceID());
                }
            }
        }

        private static string GetActiveConsoleText()
        {
            if (s_ActiveTextField == null || s_ConsoleWindowField == null)
            {
                return null;
            }

            object consoleWindow = s_ConsoleWindowField.GetValue(null);
            return consoleWindow == null ? null : s_ActiveTextField.GetValue(consoleWindow) as string;
        }

        private static bool IsFrameworkLogWrapper(string path)
        {
            string normalized = path.Replace('\\', '/');
            return normalized.EndsWith("/UnityFramework/Utility/DefaultLogHelper.cs", StringComparison.OrdinalIgnoreCase) ||
                   normalized.EndsWith("/UnityFramework/Utility/Log.cs", StringComparison.OrdinalIgnoreCase) ||
                   normalized.EndsWith("/UnityFramework/Utility/LogFormatter.cs", StringComparison.OrdinalIgnoreCase);
        }

        private static string NormalizeAssetPath(string path)
        {
            string normalized = path.Replace('\\', '/');
            string projectRoot = System.IO.Path.GetDirectoryName(Application.dataPath).Replace('\\', '/');
            if (normalized.StartsWith(projectRoot + "/", StringComparison.OrdinalIgnoreCase))
            {
                normalized = normalized.Substring(projectRoot.Length + 1);
            }
            return normalized;
        }
    }
}
