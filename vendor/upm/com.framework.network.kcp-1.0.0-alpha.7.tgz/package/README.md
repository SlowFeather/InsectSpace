# Framework Network KCP

This optional package supplies KCP 2.0.0 adapters for `com.framework.core`.

Register `KcpTransportProvider` with `INetworkManager` and create a client channel with transport id `kcp`. Server hosts can create an `INetworkServerChannel` with `KcpServerChannelProvider`.

KCP does not provide encryption or application authentication. Configure token validation and add transport security appropriate for the deployment environment.
